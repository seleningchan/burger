﻿using Microsoft.AspNetCore.Mvc;
using MyTransoOffice.Shop.Application.Dtos;
using MyTransoOffice.Shop.Application.Service;

namespace MyTransOffice.Shop.API.Controllers
{
    [ApiController]
    [Route("api/user")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost]
        public async Task<ActionResult> Register(UserDto dto)
        {
            await _userService.RegisterUser(dto);
            return Ok();
        }
    }
}
