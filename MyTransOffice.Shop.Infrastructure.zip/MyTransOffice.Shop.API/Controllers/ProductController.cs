﻿using Microsoft.AspNetCore.Mvc;
using MyTransoOffice.Shop.Application.Dtos;
using MyTransoOffice.Shop.Application.Service;

namespace MyTransOffice.Shop.API.Controllers
{
    [ApiController]
    [Route("api/product")]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpPost]
        public async Task<ActionResult> AddProduct(ProductDto dto)
        {
            await _productService.AddProductAsync(dto);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> UpdateProduct(ProductDto dto)
        {
            await _productService.UpdateProductAsync(dto);
            return Ok();
        }

        [HttpGet]
        public async Task<ActionResult> GetProduct(int userId)
        {
            var resource = await _productService.GetUserProdoctAsnyc(userId);
            return Ok(resource);
        }
    }
}
