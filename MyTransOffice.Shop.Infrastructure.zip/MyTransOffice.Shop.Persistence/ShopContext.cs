﻿using Microsoft.EntityFrameworkCore;
using MyTransOffice.Shop.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransOffice.Shop.Persistence
{
    public class ShopContext : DbContext
    {
        public ShopContext() { }
        public ShopContext(DbContextOptions<ShopContext> options):base(options) { }

        public virtual DbSet<ItemEntity> Products { get; set; }
        public virtual DbSet<UserEntity> Users { get; set; }
    }
}
