﻿using Microsoft.EntityFrameworkCore;
using MyTransOffice.Shop.Domain;
using MyTransoOffice.Shop.Application.Contracts.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransOffice.Shop.Persistence
{
    public class ProductRepository : IProductRepository
    {
        private readonly ShopContext _shopContext;

        public ProductRepository(ShopContext shopContext)
        {
            _shopContext = shopContext;
        }

        public async Task<ItemEntity> AddProductAsync(ItemEntity item)
        {
            var itemEntity = await _shopContext.Products.AddAsync(item);
            return itemEntity.Entity;
        }

        public async Task<IList<ItemEntity>> GetProductByUserIdAsync(int userId)
        {
            var items = await _shopContext.Products
                .Where(n=>n.UserId.Equals(userId))
                .ToListAsync();
            return items;
        }

        public ItemEntity UpdateProduct(ItemEntity item)
        {
            var updatedEntity =  _shopContext.Products.Update(item);
            return updatedEntity.Entity;
        }
    }
}
