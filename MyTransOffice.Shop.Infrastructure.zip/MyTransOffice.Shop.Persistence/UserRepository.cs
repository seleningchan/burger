﻿using Microsoft.EntityFrameworkCore;
using MyTransOffice.Shop.Domain;
using MyTransoOffice.Shop.Application.Contracts.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransOffice.Shop.Persistence
{
    public class UserRepository : IUserRepository
    {
        private readonly ShopContext _shopContext;

        public UserRepository(ShopContext shopContext)
        {
            _shopContext = shopContext;
        }
        public async Task<UserEntity> AddUserAsync(UserEntity user)
        {
            var addedUser = await _shopContext.Users.AddAsync(user);
            return addedUser.Entity;
        }

        public async Task<UserEntity> GeteUserAsync(string userName)
        {
            var user= await _shopContext.Users
                .Where(n=>n.UserName.Equals(userName,StringComparison.OrdinalIgnoreCase))
                .FirstOrDefaultAsync();
            return user;
        }
    }
}
