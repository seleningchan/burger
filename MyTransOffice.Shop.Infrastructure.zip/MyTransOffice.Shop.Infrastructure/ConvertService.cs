﻿using MyTransOffice.Shop.Domain;
using MyTransoOffice.Shop.Application.Dtos;
using MyTransoOffice.Shop.Application.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransOffice.Shop.Infrastructure
{
    public static class ConvertService
    {
        public static UserEntity ConvertUerEntity(this UserDto user)
        {
            return new UserEntity();
        }

        public static ItemEntity ConvertProductEntity(this ProductDto product)
        {
            return new ItemEntity();
        }

        public static ProductResource ConvertProductResource(this ItemEntity product)
        {
            return new ProductResource();
        }
    }
}
