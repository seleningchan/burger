﻿using MyTransoOffice.Shop.Application.Contracts.Persistence;
using MyTransoOffice.Shop.Application.Dtos;
using MyTransoOffice.Shop.Application.Resources;
using MyTransoOffice.Shop.Application.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransOffice.Shop.Infrastructure
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task AddProductAsync(ProductDto dto)
        {
            await _productRepository.AddProductAsync(dto.ConvertProductEntity());
        }

        public async Task<IList<ProductResource>> GetUserProdoctAsnyc(int userId)
        {
            var products = await _productRepository.GetProductByUserIdAsync(userId);
            return products.Select(p => p.ConvertProductResource()).ToList();
        }

        public Task UpdateProductAsync(ProductDto dto)
        {
            _productRepository.UpdateProduct(dto.ConvertProductEntity());
            return Task.CompletedTask;
        }
    }
}
