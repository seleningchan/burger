﻿using MyTransoOffice.Shop.Application.Contracts.Persistence;
using MyTransoOffice.Shop.Application.Dtos;
using MyTransoOffice.Shop.Application.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransOffice.Shop.Infrastructure
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<bool> CheckUser(string userName, string password)
        {
            var user= await _userRepository.GeteUserAsync(userName);
            if (user != null)
            {
                if (SecurePasswordHasher.Hash(password,30) == user.Password)
                {
                    return true;
                }
            }
            return false;
        }

        public async Task RegisterUser(UserDto userDto)
        {
            var user = await _userRepository.GeteUserAsync(userDto.UserName);
            if (user == null)
            {
                await _userRepository.AddUserAsync(userDto.ConvertUerEntity());
            }
            throw new Exception("user name existed");
        }
    }
}
