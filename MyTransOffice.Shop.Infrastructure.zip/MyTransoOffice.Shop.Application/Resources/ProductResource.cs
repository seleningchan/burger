﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransoOffice.Shop.Application.Resources
{
    public class ProductResource
    {
        public string UserName { get; set; }
        public string Description { get; set; }
        public float Quantity { get; set; }
        public float Price { get; set; } 
    }
}
