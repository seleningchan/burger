﻿using MyTransOffice.Shop.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransoOffice.Shop.Application.Contracts.Persistence
{
    public interface IProductRepository
    {
        public Task<IList<ItemEntity>> GetProductByUserIdAsync(int userId);
        public Task<ItemEntity> AddProductAsync(ItemEntity item);
        public ItemEntity UpdateProduct(ItemEntity item);
    }
}
