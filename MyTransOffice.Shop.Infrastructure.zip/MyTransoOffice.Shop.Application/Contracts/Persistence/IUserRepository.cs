﻿using MyTransOffice.Shop.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransoOffice.Shop.Application.Contracts.Persistence
{
    public interface IUserRepository
    {
        public Task<UserEntity> AddUserAsync(UserEntity user);
        public Task<UserEntity> GeteUserAsync(string userName);
    }
}
