﻿using MyTransoOffice.Shop.Application.Dtos;
using MyTransoOffice.Shop.Application.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTransoOffice.Shop.Application.Service
{
    public interface IProductService
    {
        public Task<IList<ProductResource>> GetUserProdoctAsnyc(int userId);
        public Task AddProductAsync(ProductDto dto);
        public Task UpdateProductAsync(ProductDto dto);
    }
}
